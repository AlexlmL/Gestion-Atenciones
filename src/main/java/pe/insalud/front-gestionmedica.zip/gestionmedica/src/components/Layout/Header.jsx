import { useAuth } from '../../context/useAuth';
import '../../styles/Header.css';

const Header = () => {
    const { user, logout, isAdmin } = useAuth();

    return (
        <header className="header">
            <div className="header-left">
                <h1>Sistema de Gestión Médica</h1>
            </div>
            <div className="header-right">
        <span className="user-info">
          Bienvenido, {user?.nombre} ({isAdmin ? 'Administrador' : 'Paciente'})
        </span>
                <button onClick={logout} className="logout-btn">
                    Cerrar Sesión
                </button>
            </div>
        </header>
    );
};

export default Header;