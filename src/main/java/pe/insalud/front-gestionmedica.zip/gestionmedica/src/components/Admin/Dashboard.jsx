import { useState, useEffect } from 'react';
import { getAtenciones } from '../../services/api';
import '../../styles/Dashboard.css';

const Dashboard = () => {
    const [stats, setStats] = useState({
        totalAtenciones: 0,
        atencionesHoy: 0,
        atencionesEsteMes: 0
    });
    const [recentAtenciones, setRecentAtenciones] = useState([]);
    const [loading, setLoading] = useState(true);
    const [setError] = useState('');
    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {
        try {
            const response = await getAtenciones();
            const atenciones = response.data;

            // Calcular estadísticas
            const hoy = new Date().toISOString().split('T')[0];
            const esteMes = new Date().getMonth();
            const esteAño = new Date().getFullYear();

            const atencionesHoy = atenciones.filter(a =>
                a.fecha.startsWith(hoy)
            ).length;

            const atencionesEsteMes = atenciones.filter(a => {
                const fechaAtencion = new Date(a.fecha);
                return fechaAtencion.getMonth() === esteMes &&
                    fechaAtencion.getFullYear() === esteAño;
            }).length;

            setStats({
                totalAtenciones: atenciones.length,
                atencionesHoy,
                atencionesEsteMes
            });

            // Obtener las 5 atenciones más recientes
            const recientes = [...atenciones]
                .sort((a, b) => new Date(b.fecha) - new Date(a.fecha))
                .slice(0, 5);

            setRecentAtenciones(recientes);
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            setError('Error al cargar los datos del dashboard');
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <div className="loading">Cargando dashboard...</div>;

    return (
        <div className="dashboard">
            <h2>Panel de Administración</h2>

            <div className="stats-grid">
                <div className="stat-card">
                    <h3>Total de Atenciones</h3>
                    <div className="stat-number">{stats.totalAtenciones}</div>
                </div>

                <div className="stat-card">
                    <h3>Atenciones Hoy</h3>
                    <div className="stat-number">{stats.atencionesHoy}</div>
                </div>

                <div className="stat-card">
                    <h3>Atenciones Este Mes</h3>
                    <div className="stat-number">{stats.atencionesEsteMes}</div>
                </div>
            </div>

            <div className="recent-section">
                <h3>Atenciones Recientes</h3>
                {recentAtenciones.length > 0 ? (
                    <table className="recent-table">
                        <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Paciente</th>
                            <th>Médico</th>
                            <th>Motivo</th>
                        </tr>
                        </thead>
                        <tbody>
                        {recentAtenciones.map(atencion => (
                            <tr key={atencion.id}>
                                <td>{new Date(atencion.fecha).toLocaleDateString()}</td>
                                <td>{atencion.paciente?.nombre}</td>
                                <td>{atencion.medico?.nombre}</td>
                                <td>{atencion.motivo}</td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                ) : (
                    <p>No hay atenciones recientes</p>
                )}
            </div>
        </div>
    );
};

export default Dashboard;