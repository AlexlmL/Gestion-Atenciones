import { useState, useEffect } from 'react';
import {
    getAtenciones,
    deleteAtencion,
    getAtencionesByPaciente,
    getAtencionesByMedico,
    getAtencionesByFecha,
    getPacientes,
    getMedicos
} from '../../services/api';
import '../../styles/AtencionesList.css';

// Función para extraer el nombre de un objeto (médico, paciente, etc.)
const getNombre = (objeto) => {
    if (typeof objeto === 'string') return objeto;
    if (objeto && typeof objeto === 'object') {
        return objeto.nombre || objeto.email || 'Nombre no disponible';
    }
    return 'No disponible';
};

// Función segura para obtener el estado como string
const getEstadoString = (estado) => {
    if (typeof estado === 'string') return estado;
    if (estado && typeof estado === 'object') {
        return estado.nombre || estado.descripcion || 'ACTIVO';
    }
    return 'ACTIVO';
};

// Función para extraer especialidades de un objeto médico
const getEspecialidades = (medico) => {
    if (typeof medico === 'string') return medico;

    if (medico && typeof medico === 'object') {
        // Si especialidades es un array de objetos Especialidad
        if (Array.isArray(medico.especialidades)) {
            return medico.especialidades
                .map(especialidad => especialidad.nombre || `Especialidad ${especialidad.id}`)
                .join(', ') || 'Sin especialidades';
        }

        // Si es un string o otro formato
        return medico.especialidades || medico.especialidad || 'Especialidad no disponible';
    }

    return 'No disponible';
};

const AtencionesList = () => {
    const [atenciones, setAtenciones] = useState([]);
    const [pacientes, setPacientes] = useState([]);
    const [medicos, setMedicos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [filtro, setFiltro] = useState({
        tipo: 'todos',
        pacienteId: '',
        medicoId: '',
        fecha: ''
    });

    useEffect(() => {
        fetchAtenciones();
        fetchPacientesYMedicos();
    }, []);

    const fetchAtenciones = async () => {
        try {
            const response = await getAtenciones();
            console.log('Datos de atenciones:', response.data);
            setAtenciones(response.data);
        } catch (err) {
            setError('Error al cargar las atenciones');
            console.error('Error fetching atenciones:', err);
        } finally {
            setLoading(false);
        }
    };

    const fetchPacientesYMedicos = async () => {
        try {
            const [pacientesRes, medicosRes] = await Promise.all([
                getPacientes(),
                getMedicos()
            ]);
            setPacientes(pacientesRes.data);
            setMedicos(medicosRes.data);

            // Debug para ver la estructura de médicos
            if (medicosRes.data && medicosRes.data.length > 0) {
                console.log('Estructura del primer médico:', medicosRes.data[0]);
                console.log('Especialidades del primer médico:', medicosRes.data[0].especialidades);
            }
        } catch (err) {
            console.error('Error al cargar pacientes y médicos:', err);
        }
    };

    const aplicarFiltros = async () => {
        try {
            setLoading(true);
            let response;

            switch (filtro.tipo) {
                case 'paciente':
                    response = await getAtencionesByPaciente(filtro.pacienteId);
                    break;
                case 'medico':
                    response = await getAtencionesByMedico(filtro.medicoId);
                    break;
                case 'fecha':
                    response = await getAtencionesByFecha(filtro.fecha);
                    break;
                default:
                    response = await getAtenciones();
            }

            setAtenciones(response.data);
        } catch (err) {
            setError('Error al aplicar filtros');
            console.error('Error applying filters:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('¿Estás seguro de eliminar esta atención?')) {
            try {
                await deleteAtencion(id);
                fetchAtenciones(); // Recargar la lista
            } catch (err) {
                setError('Error al eliminar la atención');
                console.error('Error deleting atencion:', err);
            }
        }
    };

    const handleFiltroChange = (e) => {
        const { name, value } = e.target;
        setFiltro(prev => ({
            ...prev,
            [name]: value
        }));
    };

    if (loading) return <div className="loading">Cargando...</div>;
    if (error) return <div className="error">{error}</div>;

    return (
        <div className="atenciones-container">
            <h2>Gestión de Atenciones</h2>

            {/* Filtros */}
            <div className="filtros">
                <select name="tipo" value={filtro.tipo} onChange={handleFiltroChange}>
                    <option value="todos">Todas las atenciones</option>
                    <option value="paciente">Por paciente</option>
                    <option value="medico">Por médico</option>
                    <option value="fecha">Por fecha</option>
                </select>

                {filtro.tipo === 'paciente' && (
                    <select name="pacienteId" value={filtro.pacienteId} onChange={handleFiltroChange}>
                        <option value="">Seleccionar paciente</option>
                        {pacientes.map(paciente => (
                            <option key={paciente.id} value={paciente.id}>
                                {getNombre(paciente)}
                            </option>
                        ))}
                    </select>
                )}

                {filtro.tipo === 'medico' && (
                    <select name="medicoId" value={filtro.medicoId} onChange={handleFiltroChange}>
                        <option value="">Seleccionar médico</option>
                        {medicos.map(medico => (
                            <option key={medico.id} value={medico.id}>
                                {getNombre(medico)}
                            </option>
                        ))}
                    </select>
                )}

                {filtro.tipo === 'fecha' && (
                    <input
                        type="date"
                        name="fecha"
                        value={filtro.fecha}
                        onChange={handleFiltroChange}
                    />
                )}

                <button onClick={aplicarFiltros}>Aplicar Filtros</button>
            </div>

            <table className="atenciones-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Fecha</th>
                    <th>Motivo</th>
                    <th>Paciente</th>
                    <th>Médico</th>
                    <th>Especialidades</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                {atenciones.map((atencion) => {
                    const estadoString = getEstadoString(atencion.estado);
                    const estadoLowerCase = estadoString.toLowerCase();
                    const pacienteNombre = getNombre(atencion.paciente);
                    const medicoNombre = getNombre(atencion.medico);
                    const especialidades = getEspecialidades(atencion.medico);

                    return (
                        <tr key={atencion.id}>
                            <td>{atencion.id}</td>
                            <td>{new Date(atencion.fecha).toLocaleDateString()}</td>
                            <td>{atencion.motivo || 'No especificado'}</td>
                            <td>{pacienteNombre}</td>
                            <td>{medicoNombre}</td>
                            <td>{especialidades}</td>
                            <td>
                                <span className={`estado-badge estado-${estadoLowerCase}`}>
                                    {estadoString}
                                </span>
                            </td>
                            <td>
                                <button
                                    onClick={() => window.location.href = `/atenciones/editar/${atencion.id}`}
                                    className="btn-editar"
                                >
                                    Editar
                                </button>
                                <button
                                    onClick={() => handleDelete(atencion.id)}
                                    className="btn-eliminar"
                                >
                                    Eliminar
                                </button>
                            </td>
                        </tr>
                    );
                })}
                </tbody>
            </table>

            {atenciones.length === 0 && (
                <div className="no-data">No hay atenciones para mostrar</div>
            )}
        </div>
    );
};

export default AtencionesList;