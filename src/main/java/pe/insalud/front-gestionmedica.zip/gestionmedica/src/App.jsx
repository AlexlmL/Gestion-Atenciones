import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/useAuth';
import {AuthProvider } from './context/AuthProvider.jsx';
import PrivateRoute from './components/Layout/PrivateRoute';
import Login from './components/Auth/Login';
import Dashboard from './components/Admin/Dashboard';
import AtencionesList from './components/Admin/AtencionesList';
import AtencionForm from './components/Admin/AtencionForm';
import MisAtenciones from './components/Paciente/MisAtenciones';
import Header from './components/Layout/Header';
import Sidebar from './components/Layout/Sidebar';
import ErrorBoundary from './components/Layout/ErrorBoundary';
import './styles/Global.css';

const AppContent = () => {
    const { isAuthenticated, isAdmin, user } = useAuth();

    console.log('User auth state:', { isAuthenticated, isAdmin, user }); // Para debugging

    return (
        <Router>
            {isAuthenticated && <Header />}
            {isAuthenticated && isAdmin && <Sidebar />}
            <div className={isAuthenticated && isAdmin ? "app-container with-sidebar" : "app-container"}>
                <Routes>
                    <Route
                        path="/login"
                        element={isAuthenticated ? <Navigate to="/" /> : <Login />}
                    />
                    <Route
                        path="/"
                        element={
                            <PrivateRoute>
                                {isAdmin ? <Dashboard /> : <MisAtenciones />}
                            </PrivateRoute>
                        }
                    />
                    {/* Rutas solo para ADMIN */}
                    {isAdmin && (
                        <>
                            <Route
                                path="/atenciones"
                                element={
                                    <PrivateRoute adminOnly>
                                        <AtencionesList />
                                    </PrivateRoute>
                                }
                            />
                            <Route
                                path="/atenciones/nueva"
                                element={
                                    <PrivateRoute adminOnly>
                                        <AtencionForm />
                                    </PrivateRoute>
                                }
                            />
                            <Route
                                path="/atenciones/editar/:id"
                                element={
                                    <PrivateRoute adminOnly>
                                        <AtencionForm />
                                    </PrivateRoute>
                                }
                            />
                        </>
                    )}
                    {/* Ruta para PACIENTE */}
                    <Route
                        path="/mis-atenciones"
                        element={
                            <PrivateRoute>
                                <MisAtenciones />
                            </PrivateRoute>
                        }
                    />
                    {/* Redirección para rutas no válidas */}
                    <Route path="*" element={<Navigate to="/" />} />
                </Routes>
            </div>
        </Router>
    );
};

const App = () => {
    return (
        <AuthProvider>
            <ErrorBoundary>
                <AppContent />
            </ErrorBoundary>
        </AuthProvider>
    );
};

export default App;