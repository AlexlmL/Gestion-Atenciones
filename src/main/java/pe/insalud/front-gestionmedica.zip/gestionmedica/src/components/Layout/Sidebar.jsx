import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/useAuth';
import '../../styles/Sidebar.css';

const Sidebar = () => {
    const { isAdmin } = useAuth();

    return (
        <aside className="sidebar">
            <nav className="sidebar-nav">
                {isAdmin ? (
                    <>
                        <NavLink
                            to="/"
                            className={({ isActive }) => isActive ? "nav-item active" : "nav-item"}
                            end
                        >
                            Dashboard
                        </NavLink>
                        <NavLink
                            to="/atenciones"
                            className={({ isActive }) => isActive ? "nav-item active" : "nav-item"}
                        >
                            Gestión de Atenciones
                        </NavLink>
                        <NavLink
                            to="/atenciones/nueva"
                            className={({ isActive }) => isActive ? "nav-item active" : "nav-item"}
                        >
                            Nueva Atención
                        </NavLink>
                    </>
                ) : (
                    <NavLink
                        to="/mis-atenciones"
                        className={({ isActive }) => isActive ? "nav-item active" : "nav-item"}
                    >
                        Mis Atenciones
                    </NavLink>
                )}
            </nav>
        </aside>
    );
};

export default Sidebar;