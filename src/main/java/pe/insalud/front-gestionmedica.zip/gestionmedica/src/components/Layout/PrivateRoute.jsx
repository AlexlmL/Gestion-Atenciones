import { useAuth } from '../../context/useAuth';
import Login from '../Auth/Login';

const PrivateRoute = ({ children, adminOnly = false }) => {
    const { isAuthenticated, isAdmin } = useAuth();

    if (!isAuthenticated) {
        return <Login />;
    }

    if (adminOnly && !isAdmin) {
        return <div>No tienes permisos para acceder a esta página</div>;
    }

    return children;
};

export default PrivateRoute;