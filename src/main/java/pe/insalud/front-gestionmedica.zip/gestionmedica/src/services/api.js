import axios from 'axios';

const API_URL = 'http://localhost:8090/api';

// Configurar interceptores (ya existentes)
axios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

axios.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('token');
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

// Servicios de Atenciones
export const getAtenciones = () => axios.get(`${API_URL}/atenciones`);
export const getMisAtenciones = () => axios.get(`${API_URL}/atenciones/mias`);
export const getAtencionesByPaciente = (id) => axios.get(`${API_URL}/atenciones/paciente/${id}`);
export const getAtencionesByMedico = (id) => axios.get(`${API_URL}/atenciones/medico/${id}`);
export const getAtencionesByFecha = (fecha) => axios.get(`${API_URL}/atenciones/fecha?fecha=${fecha}`);
export const createAtencion = (data) => axios.post(`${API_URL}/atenciones`, data);
export const updateAtencion = (id, data) => axios.put(`${API_URL}/atenciones/${id}`, data);
export const deleteAtencion = (id) => axios.delete(`${API_URL}/atenciones/${id}`);

// Servicios adicionales (para obtener pacientes y médicos)
export const getPacientes = () => axios.get(`${API_URL}/pacientes`);
export const getMedicos = () => axios.get(`${API_URL}/medicos`);
export const getAtencionById = (id) => axios.get(`${API_URL}/atenciones/${id}`);