import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
    createAtencion,
    updateAtencion,
    getPacientes,
    getMedicos, getAtencionById
} from '../../services/api';
import '../../styles/AtencionForm.css';

const AtencionForm = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const isEdit = Boolean(id);

    const [formData, setFormData] = useState({
        fecha: '',
        motivo: '',
        pacienteId: '',
        medicoId: '',
        estado: 'ACTIVO'
    });

    const [pacientes, setPacientes] = useState([]);
    const [medicos, setMedicos] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // Cargar pacientes, médicos y datos de la atención si es edición
    useEffect(() => {
        const fetchData = async () => {
            try {
                await fetchPacientesYMedicos();

                if (isEdit) {
                    const response = await getAtencionById(id);
                    const data = response.data;
                    setFormData({
                        fecha: data.fecha.split('T')[0], // convertir ISO a yyyy-mm-dd
                        motivo: data.motivo,
                        pacienteId: data.paciente.id,
                        medicoId: data.medico.id,
                        estado: data.estado
                    });
                }
            } catch (err) {
                console.error('Error cargando datos de la atención:', err);
                setError('No se pudo cargar la atención para editar');
            }
        };

        fetchData();
    }, [id, isEdit]);

    const fetchPacientesYMedicos = async () => {
        try {
            const [pacientesRes, medicosRes] = await Promise.all([
                getPacientes(),
                getMedicos()
            ]);
            setPacientes(pacientesRes.data);
            setMedicos(medicosRes.data);
        } catch (err) {
            console.error('Error fetching pacientes y médicos:', err);
            setError('Error al cargar pacientes y médicos');
        }

    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: ['pacienteId','medicoId'].includes(name) ? Number(value) : value
        }));
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const payload = {
                ...formData,
                // Enviar fecha en formato ISO local sin conversión a UTC
                fecha: formData.fecha ? `${formData.fecha}T00:00:00` : null
            };

            if (isEdit) {
                await updateAtencion(id, payload);
            } else {
                await createAtencion(payload);
            }

            navigate('/atenciones');
        } catch (error) {
            setError(error.response?.data?.message || 'Error al guardar la atención');
        } finally {
            setLoading(false);
        }
    };


    return (
        <div className="atencion-form-container">
            <h2>{isEdit ? 'Editar Atención' : 'Nueva Atención'}</h2>

            {error && <div className="error-message">{error}</div>}

            <form onSubmit={handleSubmit} className="atencion-form">
                <div className="form-group">
                    <label>Fecha:</label>
                    <input
                        type="date"
                        name="fecha"
                        value={formData.fecha}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label>Motivo:</label>
                    <textarea
                        name="motivo"
                        value={formData.motivo}
                        onChange={handleChange}
                        required
                        rows="3"
                    />
                </div>

                <div className="form-group">
                    <label>Paciente:</label>
                    <select
                        name="pacienteId"
                        value={formData.pacienteId}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Seleccionar paciente</option>
                        {pacientes.map(paciente => (
                            <option key={paciente.id} value={paciente.id}>
                                {paciente.nombre} ({paciente.email})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label>Médico:</label>
                    <select
                        name="medicoId"
                        value={formData.medicoId}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Seleccionar médico</option>
                        {medicos.map(medico => ( <option key={medico.id} value={medico.id}> {medico.nombre} - {medico.especialidades} </option> ))}
                    </select>
                </div>

                <div className="form-group">
                    <label>Estado:</label>
                    <select
                        name="estado"
                        value={formData.estado}
                        onChange={handleChange}
                        required
                    >
                        <option value="ACTIVO">Activo</option>
                        <option value="INACTIVO">Inactivo</option>
                        <option value="CANCELADO">Cancelado</option>
                    </select>
                </div>

                <div className="form-actions">
                    <button
                        type="button"
                        onClick={() => navigate('/atenciones')}
                        className="cancel-btn"
                    >
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        disabled={loading}
                        className="submit-btn"
                    >
                        {loading ? 'Guardando...' : (isEdit ? 'Actualizar' : 'Crear')}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default AtencionForm;