import { useState, useEffect } from 'react';
import AuthContext from './AuthContext';

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(localStorage.getItem('token'));
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (token) {
            try {
                // Decodificar el token JWT
                const payload = JSON.parse(atob(token.split('.')[1]));

                // Para debugging: ver qué campos trae el token
                console.log('Token payload:', payload);

                // Asegurarse de que tenemos los datos correctos del usuario
                setUser({
                    id: payload.sub,
                    nombre: payload.sub.includes('admin') ? 'Admin' : 'Usuario',
                    email: payload.sub,
                    role: payload.sub.includes('admin') ? 'ADMIN' : 'PACIENTE'
                });
            } catch (error) {
                console.error('Error decoding token:', error);
                logout();
            }
        }
        setLoading(false);
    }, [token]);

    const login = (token) => {
        localStorage.setItem('token', token);
        setToken(token);
    };

    const logout = () => {
        localStorage.removeItem('token');
        setToken(null);
        setUser(null);
    };

    const value = {
        user,
        token,
        login,
        logout,
        isAuthenticated: !!token,
        isAdmin: user?.role === 'ADMIN'
    };

    return (
        <AuthContext.Provider value={value}>
            {!loading && children}
        </AuthContext.Provider>
    );
};

export default AuthProvider;