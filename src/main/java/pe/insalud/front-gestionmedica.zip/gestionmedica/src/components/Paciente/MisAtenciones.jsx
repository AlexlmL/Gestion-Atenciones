import { useState, useEffect } from 'react';
import { getMisAtenciones } from '../../services/api';
import { useAuth } from '../../context/useAuth';
import '../../styles/MisAtenciones.css';

const MisAtenciones = () => {
    const [atenciones, setAtenciones] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const { user } = useAuth();

    useEffect(() => {
        fetchMisAtenciones();
    }, []);

    const fetchMisAtenciones = async () => {
        try {
            console.log('Fetching mis atenciones for user:', user);
            const response = await getMisAtenciones();
            console.log('Mis atenciones response:', response);
            console.log('Datos de atenciones:', response.data);

            // Debug detallado de la estructura de datos
            if (response.data && response.data.length > 0) {
                const primeraAtencion = response.data[0];
                console.log('Estructura completa de la primera atención:', primeraAtencion);
                console.log('Medico:', primeraAtencion.medico);
                console.log('Especialidades del médico:', primeraAtencion.medico?.especialidades);
                console.log('Tipo de especialidades:', typeof primeraAtencion.medico?.especialidades);
                if (primeraAtencion.medico?.especialidades) {
                    console.log('Primera especialidad:', primeraAtencion.medico.especialidades[0]);
                }
            }

            setAtenciones(response.data);
        } catch (err) {
            console.error('Error fetching mis atenciones:', err);
            setError(err.response?.data?.message || 'Error al cargar tus atenciones');
        } finally {
            setLoading(false);
        }
    };

    // Función segura para obtener el estado como string
    const getEstadoString = (estado) => {
        if (typeof estado === 'string') return estado;
        if (estado && typeof estado === 'object') {
            return estado.nombre || estado.descripcion || estado.estado || 'ACTIVO';
        }
        return 'ACTIVO';
    };

    // Función para extraer el nombre de un objeto médico
    const getMedicoNombre = (medico) => {
        if (typeof medico === 'string') return medico;
        if (medico && typeof medico === 'object') {
            return medico.nombre || `Médico ID: ${medico.id}` || 'Médico no disponible';
        }
        return 'No disponible';
    };

    // Función para extraer especialidades de un objeto médico
    const getEspecialidades = (medico) => {
        if (typeof medico === 'string') return medico;

        if (medico && typeof medico === 'object') {
            // Si especialidades es un array de objetos Especialidad
            if (Array.isArray(medico.especialidades)) {
                return medico.especialidades
                    .map(especialidad => especialidad.nombre || `Especialidad ${especialidad.id}`)
                    .join(', ') || 'Sin especialidades';
            }

            // Si es un string o otro formato
            return medico.especialidades || medico.especialidad || 'Especialidad no disponible';
        }

        return 'No disponible';
    };

    if (loading) return <div className="loading">Cargando tus atenciones...</div>;
    if (error) return <div className="error">Error: {error}</div>;

    return (
        <div className="mis-atenciones-container">
            <h2>Mis Atenciones Médicas</h2>
            <p>Bienvenido {user?.nombre || user?.email}, aquí puedes ver el historial de tus atenciones médicas.</p>

            {atenciones.length === 0 ? (
                <div className="no-data">No tienes atenciones médicas registradas</div>
            ) : (
                <div className="atenciones-list">
                    {atenciones.map((atencion) => {
                        const estadoString = getEstadoString(atencion.estado);
                        const estadoLowerCase = estadoString.toLowerCase();
                        const medicoNombre = getMedicoNombre(atencion.medico);
                        const especialidades = getEspecialidades(atencion.medico);

                        return (
                            <div key={atencion.id} className="atencion-card">
                                <h3>Atención #{atencion.id} - {new Date(atencion.fecha).toLocaleDateString()}</h3>
                                <p><strong>Motivo:</strong> {atencion.motivo || 'No especificado'}</p>
                                <p><strong>Médico:</strong> {medicoNombre}</p>
                                <p><strong>Especialidad:</strong> {especialidades}</p>
                                <p><strong>Estado:</strong>
                                    <span className={`estado-badge estado-${estadoLowerCase}`}>
                                        {estadoString}
                                    </span>
                                </p>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

export default MisAtenciones;